package vehicle;

public interface Motorized 
{
	public int getAverageFuel();
	public void setAverageFuel(int fuel);
	public int getAverageEngineLife();
	public void setAverageEngineLife(int life);
}
