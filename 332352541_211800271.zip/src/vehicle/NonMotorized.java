package vehicle;

public interface NonMotorized 
{
	public String getPowerSourceInformation();
	public char getEnergyScore();
	
	/*
	 * public void setPowerSourceInformation(String info); 
	 * public void setEnergyScore(char score);
	 */
}
