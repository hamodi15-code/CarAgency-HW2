package vehicle;

public interface Commercial 
{
	public String getLicenseType();
}
